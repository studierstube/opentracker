This is a very simple Studierstube setup.

To view the examples, enable the corresponding line in content/main.iv.

Add your content to the file content/main.iv. The camera (eyepoint) is positioned in 
0 0 1 and looks at the origin - so content placed in the origin should be 
visible. In this configuration, X is to the right, Y is up and Z is facing 
towards the viewer.

If you want to use a PIP, enable it in config/simpleUser.iv and include your 
PIP-sheet(s) in simple_stb.iv.

Tracking setup:
---------------

The camera can be controlled by using the examiner viewer controls and the 
mouse.

Stations 1-9 are controllable via the keyboard, and can be used for interaction. 

Station 2 is translated by default, to have a good starting position for the 
PIP.

Station 10 is controllable with the mouse (x,y = mouse movement, z = mouse 
wheel)

Have fun!
